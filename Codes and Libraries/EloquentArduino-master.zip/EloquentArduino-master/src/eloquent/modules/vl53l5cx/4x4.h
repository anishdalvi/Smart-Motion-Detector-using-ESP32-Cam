//
// Created by Simone on 29/05/2022.
//

#pragma once

#include "../vl53l5cx.h"

Eloquent::Modules::Vl53l5cx vllcx(4 * 4);