//
// Created by Simone on 17/03/2022.
//

#pragma once


#include "motion/NaiveMotionDetector.h"
