//
// Created by Simone on 04/03/2022.
//

#pragma once


namespace Eloquent {
    namespace Vision {
        namespace Cam {
            enum class Error {
                OK,
                INIT_ERROR,
                CAPTURE_ERROR
            };
        }
    }
}